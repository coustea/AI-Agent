---
name: mindmap
description: This skill should be used when users need to create knowledge-based mind maps from text content, organize information hierarchically, or visualize complex concepts. It supports parsing structured text, generating mind maps in multiple formats, and customizing visual styles.
---

# Mindmap Generator

## Overview

The Mindmap Generator skill enables agents to transform text content into structured visual mind maps. It provides tools for parsing hierarchical information from various text formats, generating mind maps in multiple output formats (Markdown, HTML, Mermaid, PlantUML, etc.), and customizing visual styles for different use cases.

## Workflow Decision Tree

To determine the appropriate workflow for mind map generation:

1. **Source Material Analysis**
   - If the input is **structured Markdown** with headings → Use Markdown parsing workflow
   - If the input is **plain text with indentation** → Use indentation parsing workflow
   - If the input is **unstructured text** → Use LLM-based structuring workflow
   - If the input is **existing mind map file** → Use conversion workflow

2. **Output Format Selection**
   - For **documentation integration** → Use Markdown mind map format
   - For **web visualization** → Use HTML/JavaScript format
   - For **diagram generation** → Use Mermaid or PlantUML format
   - For **presentation** → Use PowerPoint/PDF format

3. **Style Customization**
   - For **academic/research** → Use formal, hierarchical styling
   - For **brainstorming/creative** → Use colorful, radial styling
   - For **business/project** → Use clean, structured styling
   - For **education/learning** → Use simple, clear styling

## Step 1: Parse Source Material

### Markdown Parsing
To extract hierarchical structure from Markdown documents:

1. Use the `parse_markdown.py` script to analyze heading levels
2. Identify parent-child relationships based on heading hierarchy
3. Extract content for each node from paragraphs following headings
4. Generate a structured JSON representation of the mind map

Example command:
```bash
python scripts/parse_markdown.py input.md --output structure.json
```

### Indentation Parsing
To parse plain text with indentation-based hierarchy:

1. Use the `parse_indented_text.py` script to analyze indentation levels
2. Convert tabs or spaces to hierarchical levels
3. Extract node titles from each line
4. Generate structured mind map data

### LLM-Based Structuring
For unstructured text that needs intelligent organization:

1. Use the `structure_with_llm.py` script to analyze content
2. Prompt an LLM to identify main topics and subtopics
3. Create logical hierarchical relationships
4. Validate and refine the structure

## Step 2: Generate Mind Map

### Markdown Mind Map Format
To create a Markdown-based mind map for documentation:

1. Use the `generate_markdown_mindmap.py` script
2. Convert JSON structure to nested Markdown lists
3. Add emoji or bullet indicators for visual clarity
4. Include optional collapsible sections

Example output format:
```markdown
# Knowledge Map: Machine Learning

## Supervised Learning
- Classification
  - Logistic Regression
  - Decision Trees
  - Support Vector Machines
- Regression
  - Linear Regression
  - Polynomial Regression

## Unsupervised Learning
- Clustering
  - K-Means
  - Hierarchical Clustering
- Dimensionality Reduction
  - PCA
  - t-SNE
```

### HTML/JavaScript Visualization
To create interactive web-based mind maps:

1. Use the `generate_html_mindmap.js` script
2. Create an HTML file with D3.js or vis.js integration
3. Add interactive features (zoom, pan, node expansion)
4. Include styling with CSS themes

### Mermaid Diagram Format
To generate Mermaid syntax for documentation:

1. Use the `generate_mermaid.py` script
2. Create Mermaid mindmap syntax
3. Support different layout options (top-down, left-right, radial)

Example Mermaid output:
```mermaid
mindmap
  root((Machine Learning))
    Supervised Learning
      Classification
        Logistic Regression
        Decision Trees
        SVM
      Regression
        Linear Regression
        Polynomial Regression
    Unsupervised Learning
      Clustering
        K-Means
        Hierarchical
      Dimensionality Reduction
        PCA
        t-SNE
```

### PlantUML Format
To generate PlantUML mind maps:

1. Use the `generate_plantuml.py` script
2. Create PlantUML @startmindmap syntax
3. Support different styling options

## Step 3: Customize Style and Layout

### Theme Selection
To apply different visual themes:

1. **Academic Theme** - Formal colors, serif fonts, structured layout
2. **Creative Theme** - Vibrant colors, rounded nodes, radial layout
3. **Business Theme** - Corporate colors, clean lines, hierarchical layout
4. **Minimal Theme** - Monochrome, simple shapes, clean typography

Apply themes using:
```bash
python scripts/apply_theme.py structure.json --theme business --output styled.json
```

### Layout Configuration
To customize mind map layout:

1. **Hierarchical** - Traditional tree structure
2. **Radial** - Central topic with radiating branches
3. **Organic** - Free-form, natural arrangement
4. **Timeline** - Chronological arrangement for historical topics

### Node Styling
To customize individual node appearance:

1. **Size** - Based on importance or depth
2. **Color** - Thematic coloring or categorical coloring
3. **Shape** - Circles, rectangles, diamonds, clouds
4. **Icons** - Add relevant emoji or icon indicators

## Step 4: Export and Integration

### File Export
To export mind maps in various formats:

1. **Markdown** - For documentation and note-taking
2. **HTML** - For web publishing and sharing
3. **PNG/SVG** - For images and presentations
4. **PDF** - For printing and formal documents
5. **JSON** - For data interchange and further processing

### Integration with Other Tools
To integrate with existing workflows:

1. **Notion/飞书文档** - Export as Markdown for direct import
2. **Presentation Tools** - Export as SVG for PowerPoint/Keynote
3. **Project Management** - Export as JSON for task breakdown
4. **Learning Platforms** - Export as HTML for interactive learning

## Resources

### scripts/
- `parse_markdown.py` - Parse hierarchical structure from Markdown files
- `parse_indented_text.py` - Parse indentation-based hierarchies
- `structure_with_llm.py` - Use LLM to structure unstructured text
- `generate_markdown_mindmap.py` - Generate Markdown format mind maps
- `generate_html_mindmap.js` - Create interactive HTML mind maps
- `generate_mermaid.py` - Generate Mermaid diagram syntax
- `generate_plantuml.py` - Generate PlantUML mind maps
- `apply_theme.py` - Apply visual themes to mind maps
- `export_formats.py` - Export to various file formats

### references/
- `mindmap_schemas.md` - Data structures and schemas for mind maps
- `supported_formats.md` - Detailed format specifications and limitations
- `best_practices.md` - Guidelines for effective mind map creation
- `visual_design.md` - Principles of visual hierarchy and information design

### assets/
- `templates/` - Pre-designed mind map templates for common use cases
  - `academic_research.mmd` - Template for research paper organization
  - `project_planning.mmd` - Template for project management
  - `learning_path.mmd` - Template for educational content
  - `meeting_notes.mmd` - Template for meeting summarization
- `themes/` - Visual theme configurations
  - `academic.json` - Formal academic styling
  - `creative.json` - Colorful creative styling
  - `business.json` - Professional business styling
  - `minimal.json` - Clean minimal styling
- `examples/` - Example mind maps for reference
  - `machine_learning.mmd` - Machine learning concepts mind map
  - `project_management.mmd` - Project management methodology mind map
  - `language_learning.mmd` - Language learning roadmap mind map

## Usage Examples

### Example 1: Convert Lecture Notes to Mind Map
```
User: "I have lecture notes in Markdown about machine learning. Can you create a mind map?"

Agent: Use the mindmap-generator skill:
1. Parse the Markdown notes using parse_markdown.py
2. Generate a hierarchical mind map in Mermaid format
3. Apply the academic theme for clarity
4. Export as both Markdown and HTML for different uses
```

### Example 2: Brainstorming Session Visualization
```
User: "We had a brainstorming session about product features. Can you visualize it?"

Agent: Use the mindmap-generator skill:
1. Structure the unstructured notes using structure_with_llm.py
2. Generate a radial mind map for brainstorming visualization
3. Apply the creative theme with colorful nodes
4. Export as interactive HTML for team review
```

### Example 3: Project Documentation
```
User: "I need to document our software architecture as a mind map."

Agent: Use the mindmap-generator skill:
1. Parse the architecture documentation
2. Generate a hierarchical mind map showing components and relationships
3. Apply the business theme for professional presentation
4. Export as SVG for inclusion in documentation
```

## Best Practices

1. **Start with Clear Structure** - Ensure source material has logical hierarchy before parsing
2. **Limit Branch Depth** - Keep mind maps to 3-4 levels deep for readability
3. **Use Consistent Styling** - Apply themes consistently across related mind maps
4. **Consider Audience** - Choose format and style based on who will use the mind map
5. **Iterate and Refine** - Mind maps often benefit from multiple passes of refinement
6. **Combine with Other Content** - Use mind maps as part of larger documents or presentations
