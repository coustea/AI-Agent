#!/usr/bin/env python3
"""
Generate Mermaid mind map diagrams from structured data.
"""

import json
import argparse
from pathlib import Path
from typing import Dict, List, Any


class MermaidMindMapGenerator:
    """Generate Mermaid mind map diagrams."""
    
    def __init__(self, layout: str = 'top-down', theme: str = 'default'):
        self.layout = layout  # top-down, left-right, radial
        self.theme = theme
        self.indent_size = 2
        
    def generate(self, data: Dict[str, Any]) -> str:
        """Generate Mermaid mind map syntax."""
        if not data:
            return "```mermaid\nmindmap\n  root((Empty))\n```"
        
        lines = ["```mermaid", "mindmap"]
        
        # Add layout directive if not default
        if self.layout != 'top-down':
            lines.append(f"  layout {self.layout}")
        
        # Add theme if specified
        if self.theme != 'default':
            lines.append(f"  theme {self.theme}")
        
        lines.append("")  # Empty line before content
        
        def add_node(node: Dict[str, Any], level: int = 0):
            """Recursively add node to Mermaid syntax."""
            indent = "  " * level
            
            # Format node title
            title = node['title']
            
            # For root node, use double parentheses
            if level == 0:
                node_line = f"{indent}root(({title}))"
            else:
                node_line = f"{indent}{title}"
            
            lines.append(node_line)
            
            # Add children
            for child in node.get('children', []):
                add_node(child, level + 1)
        
        add_node(data)
        
        lines.append("```")
        
        return '\n'.join(lines)
    
    def generate_styled(self, data: Dict[str, Any]) -> str:
        """Generate Mermaid with enhanced styling."""
        lines = ["```mermaid", "mindmap"]
        
        # Add styling directives
        lines.append("  %%{init: {'theme': 'base', 'themeVariables': {")
        lines.append("    'primaryColor': '#FF6B6B',")
        lines.append("    'primaryTextColor': '#fff',")
        lines.append("    'primaryBorderColor': '#FF6B6B',")
        lines.append("    'lineColor': '#FF6B6B',")
        lines.append("    'secondaryColor': '#006B76',")
        lines.append("    'tertiaryColor': '#fff'")
        lines.append("  }}}%%")
        lines.append("")
        
        def add_styled_node(node: Dict[str, Any], level: int = 0, 
                           color_index: int = 0) -> int:
            """Recursively add styled node."""
            indent = "  " * level
            
            # Color palette for different levels
            colors = [
                ('#FF6B6B', '#fff'),  # Red
                ('#4ECDC4', '#fff'),  # Teal
                ('#45B7D1', '#fff'),  # Blue
                ('#96CEB4', '#000'),  # Green
                ('#FFEAA7', '#000'),  # Yellow
                ('#DDA0DD', '#000'),  # Purple
            ]
            
            title = node['title']
            
            if level == 0:
                # Root node with styling
                bg_color, text_color = colors[color_index % len(colors)]
                lines.append(f"{indent}root(({title}))")
                lines.append(f"{indent}  :::{bg_color}")
            else:
                # Child nodes with styling
                bg_color, text_color = colors[(color_index + level) % len(colors)]
                lines.append(f"{indent}{title}")
                lines.append(f"{indent}  :::{bg_color}")
            
            # Add content as tooltip if available
            if node.get('content'):
                content_preview = node['content'][:50] + ('...' if len(node['content']) > 50 else '')
                lines.append(f"{indent}  :{content_preview}")
            
            # Process children
            child_color_index = color_index + 1
            for child in node.get('children', []):
                child_color_index = add_styled_node(child, level + 1, child_color_index)
            
            return child_color_index
        
        add_styled_node(data)
        lines.append("```")
        
        return '\n'.join(lines)
    
    def generate_from_file(self, input_file: str, output_file: str = None,
                          styled: bool = False) -> str:
        """Generate Mermaid mind map from JSON file."""
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if styled:
            mermaid = self.generate_styled(data)
        else:
            mermaid = self.generate(data)
        
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(mermaid)
            print(f"Mermaid mind map saved to {output_file}")
        
        return mermaid


def main():
    parser = argparse.ArgumentParser(description='Generate Mermaid mind map diagrams')
    parser.add_argument('input_file', help='Input JSON file with mind map structure')
    parser.add_argument('--output', '-o', help='Output file for Mermaid code')
    parser.add_argument('--layout', choices=['top-down', 'left-right', 'radial'], 
                       default='top-down', help='Layout direction')
    parser.add_argument('--theme', default='default', 
                       help='Mermaid theme (default, forest, dark, neutral)')
    parser.add_argument('--styled', action='store_true', 
                       help='Generate with enhanced styling')
    
    args = parser.parse_args()
    
    # Generate Mermaid mind map
    generator = MermaidMindMapGenerator(
        layout=args.layout,
        theme=args.theme
    )
    
    mermaid = generator.generate_from_file(
        args.input_file,
        args.output,
        args.styled
    )
    
    # Print summary
    if not args.output:
        print(mermaid)
    
    # Count nodes
    with open(args.input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    def count_nodes(node):
        count = 1
        for child in node.get('children', []):
            count += count_nodes(child)
        return count
    
    total_nodes = count_nodes(data)
    print(f"\nGenerated Mermaid mind map with {total_nodes} nodes")
    print(f"Layout: {args.layout}")
    print(f"Theme: {args.theme}")
    print(f"Styled: {args.styled}")


if __name__ == '__main__':
    main()