#!/usr/bin/env python3
"""
Generate Markdown format mind maps from structured data.
"""

import json
import argparse
from pathlib import Path
from typing import Dict, List, Any


class MarkdownMindMapGenerator:
    """Generate Markdown format mind maps."""
    
    def __init__(self, use_emoji: bool = True, use_collapsible: bool = False):
        self.use_emoji = use_emoji
        self.use_collapsible = use_collapsible
        self.emoji_map = {
            'root': '🧠',
            'main': '📚',
            'topic': '📖',
            'subtopic': '📝',
            'detail': '🔹',
            'example': '💡',
            'important': '⭐',
            'question': '❓',
            'tip': '💡'
        }
    
    def generate(self, data: Dict[str, Any], title: str = None) -> str:
        """Generate Markdown mind map from structured data."""
        if not data:
            return "# Empty Mind Map\n\nNo content available."
        
        root_title = data.get('title', 'Mind Map')
        output_title = title or root_title
        
        lines = [f"# {output_title}\n"]
        
        if data.get('content'):
            lines.append(f"\n{data['content']}\n")
        
        lines.append("\n## Structure\n")
        
        def add_node(node: Dict[str, Any], level: int = 0):
            """Recursively add node to Markdown."""
            indent = "  " * level
            bullet = "-"
            
            # Add emoji if enabled
            node_title = node['title']
            if self.use_emoji:
                if level == 0:
                    emoji = self.emoji_map.get('main', '📚')
                elif level == 1:
                    emoji = self.emoji_map.get('topic', '📖')
                elif level == 2:
                    emoji = self.emoji_map.get('subtopic', '📝')
                else:
                    emoji = self.emoji_map.get('detail', '🔹')
                node_title = f"{emoji} {node_title}"
            
            # Create line
            if self.use_collapsible and level < 3:
                lines.append(f"{indent}<details>")
                lines.append(f"{indent}<summary>{bullet} {node_title}</summary>")
                lines.append(f"{indent}")
            else:
                lines.append(f"{indent}{bullet} {node_title}")
            
            # Add content if available
            if node.get('content'):
                content_indent = "  " * (level + 1)
                for content_line in node['content'].split('\n'):
                    if content_line.strip():
                        lines.append(f"{content_indent}  {content_line}")
            
            # Add children
            for child in node.get('children', []):
                add_node(child, level + 1)
            
            if self.use_collapsible and level < 3:
                lines.append(f"{indent}</details>")
        
        add_node(data)
        
        # Add legend if using emoji
        if self.use_emoji:
            lines.append("\n## Legend\n")
            lines.append("- 🧠 Main concept")
            lines.append("- 📚 Major topic")
            lines.append("- 📖 Subtopic")
            lines.append("- 📝 Detail")
            lines.append("- 🔹 Fine detail")
            lines.append("- 💡 Example/Tip")
            lines.append("- ⭐ Important point")
            lines.append("- ❓ Question to explore")
        
        return '\n'.join(lines)
    
    def generate_from_file(self, input_file: str, output_file: str = None, 
                          title: str = None) -> str:
        """Generate Markdown mind map from JSON file."""
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        markdown = self.generate(data, title)
        
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(markdown)
            print(f"Markdown mind map saved to {output_file}")
        
        return markdown


def main():
    parser = argparse.ArgumentParser(description='Generate Markdown format mind maps')
    parser.add_argument('input_file', help='Input JSON file with mind map structure')
    parser.add_argument('--output', '-o', help='Output Markdown file')
    parser.add_argument('--title', '-t', help='Title for the mind map')
    parser.add_argument('--no-emoji', action='store_true', help='Disable emoji in output')
    parser.add_argument('--collapsible', action='store_true', help='Use collapsible sections')
    
    args = parser.parse_args()
    
    # Generate mind map
    generator = MarkdownMindMapGenerator(
        use_emoji=not args.no_emoji,
        use_collapsible=args.collapsible
    )
    
    markdown = generator.generate_from_file(
        args.input_file,
        args.output,
        args.title
    )
    
    # Print summary
    if not args.output:
        print(markdown)
    
    # Count nodes
    with open(args.input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    def count_nodes(node):
        count = 1
        for child in node.get('children', []):
            count += count_nodes(child)
        return count
    
    total_nodes = count_nodes(data)
    print(f"\nGenerated mind map with {total_nodes} nodes")
    print(f"Title: {data.get('title', 'Untitled')}")


if __name__ == '__main__':
    main()