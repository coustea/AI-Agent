#!/usr/bin/env python3
"""
Parse Markdown files to extract hierarchical structure for mind map generation.
"""

import re
import json
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional


class MarkdownParser:
    """Parse Markdown files and extract hierarchical structure."""
    
    def __init__(self):
        self.nodes = []
        self.current_hierarchy = []
        
    def parse_file(self, filepath: str) -> List[Dict[str, Any]]:
        """Parse a Markdown file and return hierarchical structure."""
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        lines = content.split('\n')
        root_node = {
            'id': 'root',
            'title': 'Root',
            'level': 0,
            'content': '',
            'children': []
        }
        
        stack = [root_node]
        
        for line_num, line in enumerate(lines):
            # Check for headings
            heading_match = re.match(r'^(#{1,6})\s+(.+)$', line)
            if heading_match:
                level = len(heading_match.group(1))
                title = heading_match.group(2).strip()
                
                # Find parent based on heading level
                while len(stack) > level:
                    stack.pop()
                
                parent = stack[-1]
                node = {
                    'id': f'node_{line_num}',
                    'title': title,
                    'level': level,
                    'content': '',
                    'children': []
                }
                
                parent['children'].append(node)
                stack.append(node)
            
            # Collect content for the current node
            elif stack and not line.strip().startswith('#') and line.strip():
                current_node = stack[-1]
                if 'content' not in current_node:
                    current_node['content'] = line
                else:
                    current_node['content'] += '\n' + line
        
        return root_node['children']
    
    def to_mindmap_structure(self, nodes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Convert parsed nodes to mind map structure."""
        if not nodes:
            return {}
        
        # Find the main topic (usually the first level 1 heading)
        main_topic = None
        for node in nodes:
            if node['level'] == 1:
                main_topic = node
                break
        
        if not main_topic and nodes:
            main_topic = nodes[0]
        
        def build_mindmap_node(node: Dict[str, Any]) -> Dict[str, Any]:
            """Recursively build mind map node structure."""
            mindmap_node = {
                'id': node['id'],
                'title': node['title'],
                'content': node.get('content', ''),
                'children': []
            }
            
            for child in node.get('children', []):
                mindmap_node['children'].append(build_mindmap_node(child))
            
            return mindmap_node
        
        return build_mindmap_node(main_topic) if main_topic else {}


def main():
    parser = argparse.ArgumentParser(description='Parse Markdown files for mind map generation')
    parser.add_argument('input_file', help='Input Markdown file')
    parser.add_argument('--output', '-o', help='Output JSON file', default='mindmap_structure.json')
    parser.add_argument('--format', '-f', choices=['json', 'yaml'], default='json',
                       help='Output format')
    
    args = parser.parse_args()
    
    # Parse the Markdown file
    parser = MarkdownParser()
    nodes = parser.parse_file(args.input_file)
    
    # Convert to mind map structure
    mindmap_structure = parser.to_mindmap_structure(nodes)
    
    # Write output
    if args.format == 'json':
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(mindmap_structure, f, indent=2, ensure_ascii=False)
        print(f"Mind map structure saved to {args.output}")
    else:
        import yaml
        with open(args.output, 'w', encoding='utf-8') as f:
            yaml.dump(mindmap_structure, f, allow_unicode=True)
        print(f"Mind map structure saved to {args.output}")
    
    # Print summary
    def count_nodes(node):
        count = 1
        for child in node.get('children', []):
            count += count_nodes(child)
        return count
    
    total_nodes = count_nodes(mindmap_structure) if mindmap_structure else 0
    print(f"Parsed {total_nodes} nodes from {args.input_file}")
    print(f"Main topic: {mindmap_structure.get('title', 'N/A') if mindmap_structure else 'N/A'}")


if __name__ == '__main__':
    main()