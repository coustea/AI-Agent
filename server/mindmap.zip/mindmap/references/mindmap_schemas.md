# Mind Map Data Schemas

## Core Data Structure

### Node Schema
```json
{
  "id": "string",           // Unique identifier for the node
  "title": "string",        // Display title of the node
  "content": "string",      // Detailed content/description (optional)
  "level": "integer",       // Hierarchical level (0 = root)
  "children": ["Node"],     // Child nodes (optional)
  "metadata": {             // Additional metadata (optional)
    "color": "string",      // CSS color for visualization
    "icon": "string",       // Icon identifier
    "priority": "integer",  // Importance/priority level
    "tags": ["string"],     // Categorization tags
    "created": "timestamp", // Creation timestamp
    "updated": "timestamp"  // Last update timestamp
  }
}
```

### Mind Map Schema
```json
{
  "version": "1.0",
  "title": "string",        // Title of the mind map
  "description": "string",  // Description of the mind map
  "root": "Node",           // Root node of the mind map
  "metadata": {
    "author": "string",     // Creator of the mind map
    "created": "timestamp", // Creation timestamp
    "updated": "timestamp", // Last update timestamp
    "tags": ["string"],     // Global tags
    "theme": "string",      // Visual theme identifier
    "layout": "string"      // Layout type (hierarchical, radial, etc.)
  },
  "settings": {             // Visualization settings
    "showIcons": "boolean",
    "showContent": "boolean",
    "collapsible": "boolean",
    "animation": "boolean"
  }
}
```

## Format Specifications

### Markdown Mind Map Format
```
# Mind Map Title

## Overview
Brief description of the mind map.

## Structure
- Main Topic 1
  - Subtopic 1.1
    - Detail 1.1.1
    - Detail 1.1.2
  - Subtopic 1.2
- Main Topic 2
  - Subtopic 2.1
  - Subtopic 2.2

## Notes
Additional notes and references.
```

### Mermaid Mind Map Syntax
```mermaid
mindmap
  root((Main Topic))
    Topic 1
      Subtopic 1.1
      Subtopic 1.2
    Topic 2
      Subtopic 2.1
      Subtopic 2.2
```

### PlantUML Mind Map Syntax
```plantuml
@startmindmap
* Root Topic
** Topic 1
*** Subtopic 1.1
*** Subtopic 1.2
** Topic 2
*** Subtopic 2.1
*** Subtopic 2.2
@endmindmap
```

## Hierarchical Levels

### Level Definitions
- **Level 0 (Root)**: Central concept or main theme
- **Level 1 (Main Topics)**: Primary categories or major divisions
- **Level 2 (Subtopics)**: Secondary categories within main topics
- **Level 3 (Details)**: Specific points, examples, or details
- **Level 4+ (Fine Details)**: Additional granular information

### Recommended Depth Limits
- **For presentations**: 3-4 levels maximum
- **For documentation**: 4-5 levels maximum
- **For detailed research**: 5-6 levels maximum
- **For brainstorming**: Unlimited, but consider splitting

## Content Guidelines

### Title Best Practices
- Keep titles concise (3-7 words)
- Use action-oriented language when appropriate
- Be specific rather than generic
- Use consistent terminology

### Content Organization
- **Chunking**: Group related information together
- **Progressive Disclosure**: Start with overview, then details
- **Parallel Structure**: Use consistent grammatical structure
- **Visual Hierarchy**: Use size, color, and position to show importance

### Metadata Usage
- **Colors**: Use for categorization, not decoration
- **Icons**: Use consistently across similar nodes
- **Tags**: Use for filtering and searching
- **Priority**: Use for highlighting key concepts

## Validation Rules

### Required Fields
- All nodes must have `id` and `title`
- Root node must exist
- Node IDs must be unique within the mind map

### Structural Rules
- No circular references allowed
- Maximum depth: 10 levels (configurable)
- Maximum children per node: 50 (configurable)
- No orphaned nodes (all nodes must be reachable from root)

### Content Rules
- Title length: 1-100 characters
- Content length: 0-5000 characters per node
- No malicious or unsafe content

## Export Formats

### Supported Formats
1. **JSON** - Full data structure with metadata
2. **Markdown** - Human-readable documentation
3. **Mermaid** - Diagram syntax for documentation
4. **PlantUML** - Diagram syntax for documentation
5. **HTML** - Interactive web visualization
6. **CSV** - Tabular data for spreadsheets
7. **XML** - Structured data interchange

### Format-Specific Considerations

#### JSON Export
- Includes all metadata and settings
- Suitable for data interchange and storage
- Can be re-imported for editing

#### Markdown Export
- Focuses on content over styling
- Supports hierarchical lists
- Can include emoji and basic formatting

#### Diagram Exports (Mermaid/PlantUML)
- Focus on visual structure
- Limited content display
- Styling may be simplified

#### HTML Export
- Interactive features (zoom, pan, expand/collapse)
- Custom styling with CSS
- May require JavaScript libraries

## Integration Points

### Data Sources
- Markdown documents with headings
- JSON/YAML structured data
- CSV/Excel spreadsheets
- Database queries
- API responses

### Target Applications
- Documentation systems (Confluence, Notion, 飞书文档)
- Presentation tools (PowerPoint, Keynote)
- Project management tools (Jira, Trello, Asana)
- Learning management systems
- Knowledge bases

## Performance Considerations

### Large Mind Maps
- **Node limit**: 1000 nodes recommended maximum
- **Memory usage**: ~1KB per node estimate
- **Rendering time**: Consider pagination or lazy loading
- **Export size**: Compress or split large exports

### Optimization Strategies
- **Lazy loading**: Load nodes on demand
- **Virtualization**: Only render visible nodes
- **Caching**: Cache parsed structures
- **Incremental updates**: Update only changed nodes

## Versioning and Compatibility

### Schema Versioning
- Major version changes indicate breaking changes
- Minor version changes add features
- Patch version changes fix bugs

### Backward Compatibility
- New fields are optional in older versions
- Old fields are deprecated but supported
- Conversion utilities available for major version upgrades

### Migration Paths
- Version 1.0 to 1.1: Automatic conversion
- Version 1.x to 2.0: Manual review recommended
- Custom schemas: Provide mapping configuration